export interface Task {
    id :number;
    description:String;
    status:boolean;
}
